import os
import io
import json
import argparse
from datetime import datetime
from itertools import product

import numpy as np
import pandas as pd
import tensorflow as tf
from google.cloud import storage
import joblib
import yaml

# Chargement des hyperparamètres
FILE_DIR = os.path.dirname(__file__)
CONFIGS_PATH = os.path.join(FILE_DIR, "configs.yaml")

# Lecture des arguments fournis par Vertex AI
parser = argparse.ArgumentParser()
parser.add_argument("--data_prefix", type=str, required=True)
parser.add_argument("--pair", type=str, default="BTC_USDT")
parser.add_argument("--run_id", type=str, required=True)
parser.add_argument("--epochs", type=int, default=20)
parser.add_argument("--batch_size", type=int, default=128)
parser.add_argument("--lookback", type=int, default=60)
args = parser.parse_args()

# Préparation des chemins GCS
BUCKET_URI = args.data_prefix.rstrip("/")
BUCKET = BUCKET_URI.replace("gs://", "").split("/")[0]
BASE_PATH = "/".join(BUCKET_URI.replace("gs://", "").split("/")[1:])

PAIR = args.pair
RUN_ID = args.run_id

storage_client = storage.Client()

# Lecture d'un fichier Parquet depuis GCS
def load_parquet_from_gcs(bucket_name, blob_path):
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_path)

    if not blob.exists():
        raise FileNotFoundError(f"Missing file: gs://{bucket_name}/{blob_path}")

    buf = io.BytesIO()
    blob.download_to_file(buf)
    buf.seek(0)
    return pd.read_parquet(buf)

# Lecture du scaler depuis GCS
def load_scaler_from_gcs(bucket_name, blob_path):
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_path)

    if not blob.exists():
        raise FileNotFoundError(f"Missing scaler: gs://{bucket_name}/{blob_path}")

    buf = io.BytesIO()
    blob.download_to_file(buf)
    buf.seek(0)
    return joblib.load(buf)

# Construction des séquences LSTM
def create_sequences(df, lookback=60):
    cols = ["open", "high", "low", "close", "volume"]
    data = df[cols].values
    X, y = [], []

    for i in range(lookback, len(data)):
        X.append(data[i - lookback:i])
        y.append(data[i, 3])

    return np.array(X), np.array(y)

# Entraînement d'un modèle avec une configuration d'hyperparamètres
def train_one_config(df, cfg, epochs, best_val_loss=float("inf"), patience_factor=1.2):
    tf.keras.backend.clear_session()

    X, y = create_sequences(df, cfg["lookback"])
    print(f"Training config: {cfg} → X={X.shape}, y={y.shape}")

    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(cfg["lookback"], X.shape[2])),
        tf.keras.layers.LSTM(cfg["lstm_units"]),
        tf.keras.layers.Dense(1)
    ])

    optimizer = tf.keras.optimizers.Adam(learning_rate=cfg["learning_rate"])
    model.compile(optimizer=optimizer, loss="mse")

    history_epochs = []

    for epoch in range(epochs):
        hist = model.fit(
            X, y,
            epochs=1,
            batch_size=cfg["batch_size"],
            validation_split=0.1,
            verbose=0
        )

        val_loss = hist.history["val_loss"][0]
        history_epochs.append({"epoch": epoch + 1, "val_loss": val_loss})

        if val_loss > patience_factor * best_val_loss:
            print(f"Pruned: val_loss {val_loss:.4f} > threshold {patience_factor * best_val_loss:.4f}")
            break

        if val_loss < best_val_loss:
            best_val_loss = val_loss

    return model, history_epochs, best_val_loss

# Successive Halving
def successive_halving(df, configs, max_epochs=20, patience_factor=1.2):
    candidates = []
    best_val_loss_overall = float("inf")

    for cfg in configs:
        model, hist, best_val_loss_overall = train_one_config(
            df,
            cfg,
            epochs=max_epochs,
            best_val_loss=best_val_loss_overall,
            patience_factor=patience_factor
        )

        candidate = {
            "config": cfg,
            "history": hist,
            "final_val_loss": hist[-1]["val_loss"],
            "model": model
        }

        candidates.append(candidate)
        candidates.sort(key=lambda c: c["final_val_loss"])
        best_val_loss_overall = candidates[0]["final_val_loss"]

    return candidates

# Chargement des données d'entraînement
train_path = f"{BASE_PATH}/{PAIR}_train_{RUN_ID}.parquet"
scaler_path = f"{BASE_PATH}/scalers/scaler_{PAIR}_{RUN_ID}.pkl"

print(f"Loading training data: gs://{BUCKET}/{train_path}")
df = load_parquet_from_gcs(BUCKET, train_path)

if "timestamp" in df.columns:
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)

print(f"Loading scaler: gs://{BUCKET}/{scaler_path}")
scaler = load_scaler_from_gcs(BUCKET, scaler_path)

# Chargement des configurations hyperparamètres
with open(CONFIGS_PATH, "r") as f:
    config_yaml = yaml.safe_load(f)

configs_to_test = [
    {
        "batch_size": b,
        "lookback": l,
        "lstm_units": u,
        "learning_rate": config_yaml.get("learning_rate", 0.001)
    }
    for b, l, u in product(
        config_yaml["batch_sizes"],
        config_yaml["lookbacks"],
        config_yaml["lstm_units"]
    )
]

max_epochs = config_yaml.get("max_epochs", 20)
patience_factor = config_yaml.get("patience_factor", 1.2)

# Recherche d’hyperparamètres
all_candidates = successive_halving(
    df,
    configs_to_test,
    max_epochs=max_epochs,
    patience_factor=patience_factor
)

# Sélection du meilleur modèle
best = all_candidates[0]
model = best["model"]
history = best["history"]
best_config = best["config"]

timestamp = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
model_dir = f"{BASE_PATH}/models/{PAIR}_{RUN_ID}_{timestamp}"
bucket = storage_client.bucket(BUCKET)

# Sauvegarde du modèle
local_model_path = f"lstm_model_{PAIR}.keras"
model.save(local_model_path)
bucket.blob(f"{model_dir}/{local_model_path}").upload_from_filename(local_model_path)

# Sauvegarde du scaler
scaler_local_path = "scaler.pkl"
joblib.dump(scaler, scaler_local_path)
bucket.blob(f"{model_dir}/scaler.pkl").upload_from_filename(scaler_local_path)

# Sauvegarde du dataset utilisé
train_local_path = "train_data.parquet"
df.to_parquet(train_local_path)
bucket.blob(f"{model_dir}/train_data.parquet").upload_from_filename(train_local_path)

# Sauvegarde des métriques
metrics = {
    "run_id": RUN_ID,
    "pair": PAIR,
    "timestamp": timestamp,
    "epochs_ran": len(history),
    "final_val_loss": float(history[-1]["val_loss"]),
    "best_config": best_config
}
bucket.blob(f"{model_dir}/metrics.json").upload_from_string(json.dumps(metrics, indent=2))

# Sauvegarde des candidats
for c in all_candidates:
    c.pop("model", None)

with open("all_candidates.json", "w") as f:
    json.dump(all_candidates, f, indent=2)

bucket.blob(f"{model_dir}/all_candidates.json").upload_from_filename("all_candidates.json")

print("Training completed successfully.")
